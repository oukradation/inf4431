# Oppgave 1
a) Is there any difference in the consumption of LUTs? Which method has the shortest delay?

We observe that the xor method has much fewer components in RTL schemetics and thus less LUT used - 2 in this case against 4 LUT in other parity checker. This will imply that XOR methode will be faster with less delay.

b - e)
   see attached code


